void SPI2_conf(void);
