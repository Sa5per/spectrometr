void get_Timer_clocks(void);
void TIM_CCD_fM_conf(void);
void TIM_ADC_conf(void);
void TIM_ICG_SH_conf(void);
